from telethon import TelegramClient, events
import logging

# --- НАСТРОЙКИ ---
API_ID =   # Твой api_id
API_HASH = 'Тут_твой_апи_хеш'
# -----------------

client = TelegramClient('ghost_session', API_ID, API_HASH)

# Память для хранения последних сообщений (чтобы знать, что удалили)
message_cache = {}

logging.basicConfig(level=logging.INFO)

@client.on(events.NewMessage)
async def handler(event):
    # Сохраняем сообщение в кэш (id сообщения: текст)
    if event.is_private:
        message_cache[event.id] = {
            'text': event.text,
            'sender': event.sender_id,
            'date': event.date
        }

@client.on(events.MessageDeleted)
async def delete_handler(event):
    for msg_id in event.deleted_ids:
        if msg_id in message_cache:
            msg = message_cache[msg_id]
            log_text = (
                f"🕵️‍♂️ **Обнаружено удаление!**\n\n"
                f"👤 **От:** `{msg['sender']}`\n"
                f"🕒 **Дата:** `{msg['date']}`\n"
                f"📝 **Текст:** {msg['text']}"
            )
            # Пересылаем тебе в "Избранное"
            await client.send_message('me', log_text)
            logging.info(f"Лог удаления сохранен для сообщения {msg_id}")

@client.on(events.MessageEdited)
async def edit_handler(event):
    if event.id in message_cache:
        old_text = message_cache[event.id]['text']
        new_text = event.text
        if old_text != new_text:
            log_text = (
                f"✏️ **Сообщение изменено!**\n\n"
                f"❌ **Было:** {old_text}\n"
                f"✅ **Стало:** {new_text}"
            )
            await client.send_message('me', log_text)
            message_cache[event.id]['text'] = new_text

print("👻 Ghost Logger запущен и следит за тенями...")
client.start()
client.run_until_disconnected()
